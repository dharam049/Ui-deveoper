/*angular */
'use strict';

var cartCtrl = angular.module('cartCtrl', []);

cartCtrl.controller('ListCtrl', [

    function () {}
]);

cartCtrl.controller('CheckoutCtrl', [

    function () {}
]);
